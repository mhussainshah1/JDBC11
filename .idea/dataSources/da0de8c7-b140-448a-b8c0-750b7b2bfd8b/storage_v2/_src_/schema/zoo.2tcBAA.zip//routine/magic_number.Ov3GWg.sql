create
    definer = root@localhost procedure magic_number(OUT num int) reads sql data
BEGIN
       	SET num = 42;
    END;

