create
    definer = root@localhost procedure double_number(INOUT num int) reads sql data
BEGIN
        SET num = num * 2;
    END;

