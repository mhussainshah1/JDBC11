create
    definer = root@localhost procedure read_names_by_letter(IN prefix varchar(10)) reads sql data
BEGIN
        SELECT * FROM names WHERE name LIKE CONCAT(prefix, '%');
    END;

