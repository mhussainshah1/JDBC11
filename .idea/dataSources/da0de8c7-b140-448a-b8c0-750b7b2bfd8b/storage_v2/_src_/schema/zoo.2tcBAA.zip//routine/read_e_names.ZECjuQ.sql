create
    definer = root@localhost procedure read_e_names() reads sql data
BEGIN
        select * from names;
    END;

